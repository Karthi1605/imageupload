function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (username === 'admin' && password === 'root') {
      alert('Login successful!');
      window.location.href = '/upload';
    } else {
      alert('Invalid username or password');
    }
  }
  